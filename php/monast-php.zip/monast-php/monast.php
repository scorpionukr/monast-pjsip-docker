<?php

/*
* Copyright (c) 2008-2011, Diego Aguirre
* All rights reserved.
* 
* Redistribution and use in source and binary forms, with or without modification,
* are permitted provided that the following conditions are met:
* 
*     * Redistributions of source code must retain the above copyright notice, 
*       this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright notice, 
*       this list of conditions and the following disclaimer in the documentation 
*       and/or other materials provided with the distribution.
*     * Neither the name of the DagMoller nor the names of its contributors
*       may be used to endorse or promote products derived from this software 
*       without specific prior written permission.
* 
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
* BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
* DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE 
* OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
* OF THE POSSIBILITY OF SUCH DAMAGE.
*/

require_once 'lib/include.php';

session_start();
setValor('Actions', array());
setValor('LastReload', time());
$servers   = array();
$server    = getValor('Server', 'session');
$errors    = array();
$username  = getValor('username', 'session');
session_write_close();

$template = new TemplatePower('template/monast.html');

$response = doGet("listServers");
switch ($response)
{
	case "ERROR :: Connection Refused":
	case "ERROR :: Authentication Required":
		session_start();
		setValor('login', false);
		session_write_close();
		header("Location: index.php");
		die;
		break;

	case "ERROR :: Request Not Found":
		$error  = "The request to http://" . HOSTNAME . ":" . HOSTPORT . "/getUpdates was not found.<br>";
		$error .= "Make sure monast.py is running so the panel can connect to its port properly.";
		session_start();
		setValor('error', $error);
		session_write_close();
		header("Location: index.php");
		die;
		break;

	case "ERROR :: Internal Server Error":
		$error  = "We got \"Internal Server Error\" connecting to http://" . HOSTNAME . ":" . HOSTPORT . "/getUpdates.<br>";
		$error .= "Please lookup log file and report errors at http://monast.sf.net";
		session_start();
		setValor('error', $error);
		session_write_close();
		header("Location: index.php");
		die;
		break;
		
	default:
		$servers = monast_json_decode($response);
		sort($servers);
		session_start();
		setValor('Servers', $servers);
		if (!$server || array_search($server, $servers) === false)
		{
			$server = $servers[0];
			setValor('Server', $server);
		}
		session_write_close();
		break;
}

$status   = null;
$response = doGet("getStatus", array("servername" => $server));
switch ($response)
{
	case "ERROR :: Connection Refused":
	case "ERROR :: Authentication Required":
		session_start();
		setValor('login', false);
		session_write_close();
		header("Location: index.php");
		die;
		break;

	case "ERROR :: Request Not Found":
		$error  = "The request to http://" . HOSTNAME . ":" . HOSTPORT . "/getUpdates was not found.<br>";
		$error .= "Make sure monast.py is running so the panel can connect to its port properly.";
		session_start();
		setValor('error', $error);
		session_write_close();
		header("Location: index.php");
		die;
		break;

	case "ERROR :: Internal Server Error":
		$error  = "We got an Internal Server Error connecting to http://" . HOSTNAME . ":" . HOSTPORT . "/getUpdates.<br>";
		$error .= "Please lookup log file and report errors at http://monast.sf.net";
		session_start();
		setValor('error', $error);
		session_write_close();
		header("Location: index.php");
		die;
		break;

	default:
		$status = monast_json_decode($response);
		break;
}

$templateContent = "";
$dir = opendir("template");
while (($file = readdir($dir)))
{
	if (preg_match("/^template_.*\.html$/", $file) && $file != "template_default.html")
		$templateContent .= file_get_contents("template/$file");
	
	if ($file == "user_template_$username.html")
	{
		$templateContent = file_get_contents("template/user_template_$username.html");
		break;
	}
} 
closedir($dir);

$template->prepare();
$template->assign("templates", $templateContent . file_get_contents("template/template_default.html"));
$template->assign('MONAST_CALL_TIME', MONAST_CALL_TIME ? 'true' : 'false');
$template->assign('MONAST_BLINK_ONCHANGE', MONAST_BLINK_ONCHANGE ? 'true' : 'false');
$template->assign('MONAST_BLINK_COUNT', MONAST_BLINK_COUNT);
$template->assign('MONAST_BLINK_INTERVAL', MONAST_BLINK_INTERVAL);
$template->assign('MONAST_KEEP_CALLS_SORTED', MONAST_KEEP_CALLS_SORTED ? 'true' : 'false');
$template->assign('MONAST_KEEP_PARKEDCALLS_SORTED', MONAST_KEEP_PARKEDCALLS_SORTED ? 'true' : 'false');
$template->assign('MONAST_GROUP_BY_TECH', MONAST_GROUP_BY_TECH ? 'true' : 'false');
$template->assign('MONAST_USERNAME', $username);

if (MONAST_CLI_TAB)
{
	$template->newBlock('cli_tab');
	$template->newBlock('cli_tab_div');
}

if (MONAST_DEBUG_TAB || getValor('debug'))
{
	$template->newBlock('debug_tab');
	$template->newBlock('debug_tab_div');
}

// Users/Peers
$serverPeers = array("MonAst" => $status[$server]['peers']);
if (MONAST_GROUP_BY_TECH)
{
	$serverPeers = array();
	foreach ($status[$server]['peers'] as $peer)
	{
		if (!array_key_exists($peer['channeltype'], $serverPeers))
			$serverPeers[$peer['channeltype']] = array();
		
		$serverPeers[$peer['channeltype']][] = $peer;
	}
}

$techs = array_keys($serverPeers);
sort($techs);
foreach ($techs as $tech)
{
	$peers = $serverPeers[$tech];
	
	if (count($peers) > 0)
	{
		$template->newBlock('technology');
		$template->assign('technology', $tech);
		$template->assign('count', count($peers));
		
		$groups = array();
		
		foreach ($peers as $idx => $peer)
		{
			$template->newBlock('process');
			$template->assign('json', str_replace("'", "\'", monast_json_encode(($peer))));
			
			if (array_key_exists("peergroup", $peer))
			{
				if (array_key_exists($peer["peergroup"], $groups))
					$groups[$peer["peergroup"]] += 1;
				else 
					$groups[$peer["peergroup"]] = 1;
			}
		}
		
		foreach ($groups as $group => $count)
		{
			if ($group != "No Group")
			{
				$template->newBlock('peergroup');
				$template->assign('technology', $tech);
				$template->assign('group', $group);
				$template->assign('count', $count);
			}
		}
		if (array_key_exists("No Group", $groups))
		{
			$template->newBlock('peergroup');
			$template->assign('technology', $tech);
			$template->assign('group', "No Group");
			$template->assign('count', $groups["No Group"]);
		}
	}
}

// Channels and Bridges
foreach ($status[$server]['channels'] as $channel)
{
	$channel['channel'] = htmlentities($channel['channel']);
	
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($channel))));
}
foreach ($status[$server]['bridges'] as $bridge)
{
	$bridge['channel']        = htmlentities($bridge['channel']);
	$bridge['bridgedchannel'] = htmlentities($bridge['bridgedchannel']);
	
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($bridge))));
}

// Meetmes
foreach ($status[$server]['meetmes'] as $meetme)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($meetme))));
}

// Parked Calls
foreach ($status[$server]['parkedCalls'] as $parked)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($parked))));
}

// Queues
foreach ($status[$server]['queues'] as $queue)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($queue))));
}
foreach ($status[$server]['queueMembers'] as $queueMember)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($queueMember))));
}
foreach ($status[$server]['queueClients'] as $queueClient)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($queueClient))));
}
foreach ($status[$server]['queueCalls'] as $queueCall)
{
	$template->newBlock('process');
	$template->assign('json', str_replace("'", "\'", monast_json_encode(($queueCall))));
}

$template->printToScreen();

?>
